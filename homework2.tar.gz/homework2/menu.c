/**************************************************************************************************/
/* Copyright (C) Cai Shuxiao, SSE@USTC, 2014-2015                                                 */
/*                                                                                                */
/*  FILE NAME              :  menu.c                                                              */
/*  PRINCIPAL AUTHOR       :  Cai shuxiao                                                         */
/*  SUBSYSTEM NAME         :  menu                                                                */
/*  MODULE NAME            :  menu                                                                */
/*  LANGUAGE               :  C                                                                   */
/*  TARGET ENVIRONMENT     :  ANY                                                                 */
/*  DATE OF FIRST RELEASE  :  2014/09/16                                                          */
/*  DESCRIPTION            :  This programme shows a menu of strings                              */
/**************************************************************************************************/

/*
 * Revision Log:
 *
 * Created by Caishuxiao, 2014/9/16
 *
 */
#include<stdio.h>
#include<stdlib.h>
#include"menu.h"
/*
 *  menu program
 */
void menu()
{
    ShowAllCmd(head);
    while(1)
    {
        char cmd[CMD_MAX_LEN];
	printf("ftp[Enter]>");
        scanf("%s", cmd);
        tDataNode* p = FindCmd(head, cmd);
        if(p == NULL)
        {
            printf("This is a wrong cmd!\n");
            continue;
        }
        if(p->handler != NULL)
        {
            p -> handler();
        }
    }
}
    
int Help()
{
    tDataNode* p = head;
    printf("%s - %s\n", p->cmd, p->desc);
    ShowAllCmd(head);
    return 0;
}
int Version()
{
    tDataNode* p = &head[1];
    printf("%s - %s\n", p->cmd, p->desc);
}
int Quit()
{
    tDataNode* p = &head[2];
    printf("%s - %s\n", p->cmd, p->desc);
    exit(0);
}

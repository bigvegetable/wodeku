1.
gcc menu.c linklist.c test.c -o test
2.
./test

/**************************************************************************************************/
/* Copyright (C) Cai Shuxiao, SSE@USTC, 2014-2015                                                 */
/*                                                                                                */
/*  FILE NAME              :  linklist.c                                                          */
/*  PRINCIPAL AUTHOR       :  Cai shuxiao                                                         */
/*  SUBSYSTEM NAME         :  menu                                                                */
/*  MODULE NAME            :  linklist                                                            */
/*  LANGUAGE               :  C                                                                   */
/*  TARGET ENVIRONMENT     :  ANY                                                                 */
/*  DATE OF FIRST RELEASE  :  2014/09/22                                                          */
/*  DESCRIPTION            :  This is linklist for menu program                                   */
/**************************************************************************************************/

/*
 * Revision Log:
 *
 * Created by Caishuxiao, 2014/09/22
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"linklist.h"

tDataNode* FindCmd(tDataNode* head, char* cmd)
{
    if(head == NULL || cmd == NULL)
    {
        return NULL;
    }
    tDataNode* p = head;
    while(p != NULL)
    {
        if(!strcmp(p->cmd, cmd))
        {
            return p;    
    	    break;
        }
        p = p->next;
    }
    return NULL;
}

void ShowAllCmd(tDataNode* pHead)
{
    printf("All command supported:\n");
    tDataNode* p = pHead;
    while(p != NULL)
    {
        printf("    %s - %s\n", p->cmd, p->desc);
        p = p->next;
    }
}

/**************************************************************************************************/
/* Copyright (C) Cai Shuxiao, SSE@USTC, 2014-2015                                                 */
/*                                                                                                */
/*  FILE NAME              :  linklist.h                                                         */
/*  PRINCIPAL AUTHOR       :  Cai shuxiao                                                         */
/*  SUBSYSTEM NAME         :  menu                                                                */
/*  MODULE NAME            :  linklist                                                            */
/*  LANGUAGE               :  C                                                                   */
/*  TARGET ENVIRONMENT     :  ANY                                                                 */
/*  DATE OF FIRST RELEASE  :  2014/09/22                                                          */
/*  DESCRIPTION            :  This is linklist for menu program                                   */
/**************************************************************************************************/

/*
 * Revision Log:
 *
 * Created by Caishuxiao, 2014/09/22
 *
 */
typedef struct DataNode
{
    char* cmd;
    char* desc;
    int   (*handler)();
    struct DataNode *next;
} tDataNode;

tDataNode* FindCmd(tDataNode* head, char* cmd);

void ShowAllCmd();

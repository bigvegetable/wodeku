/**************************************************************************************************/
/* Copyright (C) Cai Shuxiao, SSE@USTC, 2014-2015                                                 */
/*                                                                                                */
/*  FILE NAME              :  menu.h                                                              */
/*  PRINCIPAL AUTHOR       :  Cai shuxiao                                                         */
/*  SUBSYSTEM NAME         :  menu                                                                */
/*  MODULE NAME            :  menu                                                                */
/*  LANGUAGE               :  C                                                                   */
/*  TARGET ENVIRONMENT     :  ANY                                                                 */
/*  DATE OF FIRST RELEASE  :  2014/09/22                                                          */
/*  DESCRIPTION            :  head file of menu.c                                                 */
/**************************************************************************************************/

/*
 * Revision Log:
 *
 * Created by Caishuxiao, 2014/9/22
 *
 */

#include"linklist.h"
#define CMD_MAX_LEN 128
/*
 *  menu program
 */
int Help();
int Version();
int Quit();
static tDataNode head[] =
{
    {"help", "This is help cmd!", Help, &head[1]},
    {"version", "menu program v1.1", Version, &head[2]},
    {"quit","This is quit cmd!", Quit, NULL}
};
void menu();

/**************************************************************************************************/
/* Copyright (C) Cai Shuxiao, SSE@USTC, 2014-2015                                                 */
/*                                                                                                */
/*  FILE NAME              :  test.c                                                              */
/*  PRINCIPAL AUTHOR       :  Cai shuxiao                                                         */
/*  SUBSYSTEM NAME         :  menu                                                                */
/*  MODULE NAME            :  test                                                                */
/*  LANGUAGE               :  C                                                                   */
/*  TARGET ENVIRONMENT     :  ANY                                                                 */
/*  DATE OF FIRST RELEASE  :  2014/09/22                                                          */
/*  DESCRIPTION            :  This programme use menu by menu.h                                   */
/**************************************************************************************************/

/*
 * Revision Log:
 *
 * Created by Caishuxiao, 2014/9/22
 *
 */
#include<stdio.h>
#include<stdlib.h>
#include"menu.h"
/*
 *  menu program
 */
main()
{
    printf(">> this is a test program <<\n>> Try menu program now   <<\n");
    menu();
}
